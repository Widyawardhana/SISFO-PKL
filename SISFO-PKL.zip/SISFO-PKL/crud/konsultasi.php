<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>halaman konsultasi</title>
</head>
<body>
    <div class="chat-container">
        <h2>Konsultasi Chat</h2>
        <div class="chat-box" id="chatbox"></div>
        <input type="text" id="chatInput" class="chat-input"placeholder="tulis pesan...">
        <button onclick="sendMessage()">kirim</button>
</div>
        <script>
            function sendMedssage() {
                const chatInput = document.getElemenById('chatInput');
                const chatBox = document.getElemenById('chatBox');
                const message = chatInput.value.trim('');

                if(message){
                    const userMessage = document.createElement('div');
                    userMessage.className = 'message user';
                    userMessage.innerText = message;
                    chatBox.appendChild(userMessagge);
                
                    const adminMessage = document.createElement('div');
                    adminMessage.className = 'message admin';
                    adminMessage.innerText = 'terima kasih telah memberii pesan,ada yang bisasaya bantu? untuk info lebih lanjut boleh contact kami di 01234567890';
                    chatBox.appendChild(adminMessage);
                    chatBox.scrollTop = chatBox.scrollHeight;
                    chatInput.value = '';
                }
            }
        </script>
</body>
</html>