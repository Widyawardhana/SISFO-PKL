<footer>
    <p>SMEKDA Coding - Design By Widya</p>
</footer>