<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Sistem Informasi PKL di PT. Maju Terus</title>
    <style>
        body{
            font-family:arial, sans-serif;
            padding:0;
            margin:0;
            background-color:white;  
        }
        header,footer{
            background-color:#D9A299;
            color:black;
            text-align:center;
            padding:20px 0;
        }
        nav{
            background-color:#DCC5B2;
            padding:10px;
            text-align:center;
        }
        nav a{
            color:white;
            margin:0 15px;
            text-decoration:none;
        }
        nav a:hover{
            text-decoration:underline;
        }
        #content{
            padding:20px;
        }
        iframe{
            width:100%;
            height:400px;
            border:none;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <?php include 'menu.php'; ?>
    <div id="content">
        <iframe name="contentFrame" src="crud/home.php"></iframe>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>