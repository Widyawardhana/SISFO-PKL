<header>
    <h1>Sistem Informasi PKL SMKN 9 MEDAN</h1>
    <p>Halaman Untuk Isi Jurnal Dan Absen Serta Konsultasi Dengan Pembimbing </p>
</header>